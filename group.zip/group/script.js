// Mobile Menu Toggle
const burger = document.querySelector('.burger');
const nav = document.querySelector('.nav-links');

burger.addEventListener('click', () => {
    // Toggle the navigation menu
    nav.classList.toggle('active');
    // Animate the burger icon
    burger.classList.toggle('toggle');
});

// Close the menu when clicking outside
document.addEventListener('click', (e) => {
    if (!nav.contains(e.target) && !burger.contains(e.target)) {
        nav.classList.remove('active');
        burger.classList.remove('toggle');
    }
});