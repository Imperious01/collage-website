// Map configuration
const collegeAddress = "6JC8+P28, high school near Panchberia, Panchberi Colony, West Bengal 741501";
let map;
let marker;
let mapInitialized = false;
let geocoder;

// Show loading state
function showLoadingState() {
    const mapContainer = document.getElementById('map');
    mapContainer.innerHTML = '<div class="map-loading"><i class="fas fa-spinner fa-spin"></i> Loading map...</div>';
}

// Show error state
function showErrorState(message) {
    const mapContainer = document.getElementById('map');
    mapContainer.innerHTML = `<div class="map-error"><i class="fas fa-exclamation-circle"></i> ${message}</div>`;
}

// Initialize the map
function initMap() {
    try {
        if (!document.getElementById('map')) {
            console.error('Map container not found');
            return;
        }

        showLoadingState();

        // Initialize geocoder
        geocoder = new google.maps.Geocoder();

        // First, geocode the address to get coordinates
        geocoder.geocode({ address: collegeAddress }, function(results, status) {
            if (status === 'OK' && results[0]) {
                const location = results[0].geometry.location;
                
                // Create the map with the geocoded location
                map = new google.maps.Map(document.getElementById('map'), {
                    center: location,
                    zoom: 16,
                    mapTypeControl: true,
                    streetViewControl: true,
                    fullscreenControl: true,
                    zoomControl: true,
                    gestureHandling: 'greedy',
                    styles: [
                        {
                            featureType: 'poi',
                            elementType: 'labels',
                            stylers: [{ visibility: 'off' }]
                        }
                    ]
                });

                // Add college marker
                marker = new google.maps.Marker({
                    position: location,
                    map: map,
                    title: 'College Location',
                    animation: google.maps.Animation.DROP,
                    icon: {
                        url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png',
                        scaledSize: new google.maps.Size(32, 32)
                    }
                });

                // Add info window
                const infoWindow = new google.maps.InfoWindow({
                    content: `
                        <div class="info-window">
                            <h4>College Name</h4>
                            <p>${collegeAddress}</p>
                            <div class="info-window-actions">
                                <button onclick="getDirections()">Get Directions</button>
                            </div>
                        </div>
                    `
                });

                // Show info window on marker click
                marker.addListener('click', () => {
                    infoWindow.open(map, marker);
                });

                // Show info window by default
                infoWindow.open(map, marker);

                mapInitialized = true;
            } else {
                console.error('Geocode was not successful for the following reason: ' + status);
                showErrorState('Could not find the location. Please try again later.');
            }
        });
    } catch (error) {
        console.error('Error initializing map:', error);
        showErrorState('Error loading map. Please check your internet connection and try again.');
    }
}

// Center the map on college location
function centerMap() {
    if (map && mapInitialized && marker) {
        map.setCenter(marker.getPosition());
        map.setZoom(16);
    } else {
        showErrorState('Map not initialized. Please refresh the page.');
    }
}

// Get and show user's current location
function getCurrentLocation() {
    if (!mapInitialized) {
        showErrorState('Map not initialized. Please refresh the page.');
        return;
    }

    if (!navigator.geolocation) {
        showErrorState('Geolocation is not supported by your browser');
        return;
    }

    showLoadingState();

    navigator.geolocation.getCurrentPosition(
        (position) => {
            const userLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            
            // Add user location marker
            new google.maps.Marker({
                position: userLocation,
                map: map,
                title: 'Your Location',
                icon: {
                    url: 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png',
                    scaledSize: new google.maps.Size(32, 32)
                }
            });

            // Center map between college and user location
            const bounds = new google.maps.LatLngBounds();
            bounds.extend(marker.getPosition());
            bounds.extend(userLocation);
            map.fitBounds(bounds);
        },
        (error) => {
            console.error('Geolocation error:', error);
            showErrorState('Error getting your location: ' + error.message);
        }
    );
}

// Get directions to college
function getDirections() {
    if (!navigator.geolocation) {
        showErrorState('Geolocation is not supported by your browser');
        return;
    }

    navigator.geolocation.getCurrentPosition(
        (position) => {
            const userLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            
            const directionsUrl = `https://www.google.com/maps/dir/?api=1&origin=${userLocation.lat},${userLocation.lng}&destination=${marker.getPosition().lat()},${marker.getPosition().lng()}&travelmode=driving`;
            window.open(directionsUrl, '_blank');
        },
        (error) => {
            console.error('Geolocation error:', error);
            showErrorState('Error getting your location: ' + error.message);
        }
    );
}

// Load Google Maps API
function loadGoogleMaps() {
    if (window.google && window.google.maps) {
        initMap();
        return;
    }

    showLoadingState();

    const script = document.createElement('script');
    script.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyB41DRUbKWJHPxaFjMAwdrzWzbVKartNGg&callback=initMap';
    script.async = true;
    script.defer = true;
    script.onerror = function() {
        console.error('Error loading Google Maps API');
        showErrorState('Error loading Google Maps. Please check your internet connection and try again.');
    };
    document.head.appendChild(script);
}

// Initialize when the page loads
document.addEventListener('DOMContentLoaded', function() {
    loadGoogleMaps();
}); 